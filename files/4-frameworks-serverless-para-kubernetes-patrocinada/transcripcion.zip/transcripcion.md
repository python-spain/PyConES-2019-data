# Frameworks Serverless para Kubernetes

(SLIDE 3) Buen día, mi nombre es Gustavo Marin, trabajo en Intelygenz como software developer. Llevo muchos años haciendo software, pero apenas un año con Python.

(SLIDE 4, INTRO) Hoy vamos a hablar de Frameworks Serverless para Kubernetes. Y para ello os voy mostrar la experiencia que tuvimos haciendo pruebas con todos ellos.

(SLIDE 5, BEFORE) Para esta charla es necesario conocer un poco el contexto de trabajo. Las piezas necesarias de conocer son las siguientes: Docker, Kubernetes y AWS Lambda. No es necesario conocerlos en profundidad, pero sí saber que es cada uno. Lo resumo en una diapositiva.

(SLIDE 6, WHAT)
  - Docker es un conjunto de herramientas que te permite empaquetar en un contenedor y distribuir el mínimo del sistema operativo y software necesario para ejecutar tu código.

  - Al acumular varios de estos contenedores aumenta la complejidad y entra en juego Kubernetes, que es una forma administrar la complejidad de gestión de todos esos contenedores de forma simple, con ficheros YML.

  - Y por último AWS Lambda, que no es parte de la charla como tal, pero es lo que inspira a estos frameworks serverless. Es el servicio que estos Frameworks intentan emular.

(SLIDE 7, FRAMEWORKS) Hay disponibles muchos frameworks para trabajar con funciones serverless, de ellos algunos se pueden desplegar directamente en Kubernetes. Pero aun así este conjunto es amplio.

(SLIDE 8, PICKS) Y como no se pueden probar todos, hemos seleccionado cuatro. Nuestra primera criba sin conocer en detalle los sistemas, es un poco estándar. Documentación, actividad de la comunidad, cantidad de estrellas en GitHub y cantidad de incidencias abiertos y totales.

Con estos criterios nos hemos quedados con esta selección: OpenFaas, Kubeless, Fission y Nuclio.


(SLIDE 9, FEATURES) Estos frameworks tienen una buena parte de sus características en común y puntos muy diferenciados.

Las características comunes son que todos soportan distintos lenguajes (Python, NodeJS, Go, etc).

- Todos te permiten, como developer, desentenderse un poco de la infraestructura y los contenedores.
- Permiten asociar eventos de tipo HTTP para invocar a las funciones.
- Todos intentan simplificar el despliegue enrutamiento, escalabilidad y disponibilidad de las funciones.
- Y disponen de un CLI.


Luego cada uno tiene sus ventajas y puntos fuertes y se diferencian en los siguientes aspectos:

- La cantidad y los tipos de integraciones con fuente de eventos
- La forma de interacción con las funciones, el contexto, el manejo de la entrada y salida, el formato de los logs, etc.
- La arquitectura y la forma de monitorización cambia bastante entre cada uno.
- Y las funcionalidades incluidas en casa CLI.

(SLIDE 10, POC) Antes de empezar a escribir código, definimos una prueba de concepto que nos permitiera evaluar todos los frameworks.


(SLIDE 11, POC) Definimos cuatro funciones separadas.

- La primera en Python que busca un autor en una lista de autores.
- Otra en Go que dado un autor te muestra una lista de libros.
- Otra en Node que con un autor y una lista de libros, formatea y envía mensajes a un canal de slack.


(SLIDE 12, WORKFLOW) Y una última que combina las tres anteriores en secuencia que se invoca con el nombre de un autor y acaba con el envío de sus libros a Slack.

Esta última la consideramos importante para probar cómo de fácil es la interacción de las distintas funciones sin salir de Kubernetes. Solo con comunicación entre servicios.

(----- SOURCE CODE----)


(SLIDE 17, EXPERIENCE) Una vez seleccionado los frameworks e implementadas las soluciones para todos ellos, esta ha sido nuestra experiencia.


(SLIDE 18, COMPARISON TABLE)

En esta tabla se incluye un breve resumen de la actividad de la comunidad en cada proyecto. No solo en cantidad de estrellas, sino el nivel de tickets abiertos y resueltos.

La instalación es sencilla en cualquier de ellos, o con helm charts o apenas un pocos yml aplicados en Kubernetes y lo tienes funcionando. En apenas minutos puedes tener cada framework instalado y con la primer función de la guía rápida funcionando.

Todos proveen un CLI, pero hemos encontrado que los más facil de utilizar, más allá de las típicas "guías de inicio rápido", han sido el de OpenFaas y el de Nuclio. Tanto Kubeless como Fission nos han resultado mas complicadas de usar. Kubeless por demasiado "verbosa" en opciones y parametros, y Fission por cantidad de pasos necesarios.

La cantidad de documentación disponible de cada uno. Tanto cantidad como calidad, y aquí es donde más se nota el estado de todos ellos, ya que la documentación suele ser escasa y no actualizada o no va más allá del tutorial básico.

La curva de aprendizaje es similar en todos ellos, pero aquí se pueden destacar dos, tanto OpenFaas como Nuclio, que presentan conceptos claros y sencillos y puedes ir subiendo la complejidad a medida que entras más en el tema. Para Fission necesitas primero entender todos los conceptos que propone para usarlo con más soltura.

Durante la implementación de la POC de cada framework nos hemos topado con algún tipo de problema. Esto es normal con tecnologías tan nuevas y no muy maduras. Pero nos ha resultado bastante costoso el debugging en todos ellos. Tal vez en Nuclio algo menos, ya que nos resulto mas facil sacar los logs y usar el contexto de logging integrado en la propia función.

La integración de Python con todos ellos está soportada. Y tal vez un poco peor en el caso de Fission porque nos ha resultado más complicada y parece más un parche que una feature del framework.


(SLIDE 19, REMARKS)

Aparte de las comparaciones, hay algunas características, buenas y no tanto, de cada framework.

Con OpenFaas es muy fácil de empezar y el CLI está muy bien diseñado para seguir todo el ciclo de vida de cada función desde el desarrollo al despliegue. Con un solo YAML de configuración se pueden desplegar varias funciones como un conjunto, muy útil porque es muy posible que quieras desarrollar unas cuantas funciones que puedan estar relacionadas. Los mayores problemas que encontramos con este sistema ha sido a la hora de interactuar con la entrada/salida, que te da en formato de array de bytes. También ha sido el único que se ha roto al hacer una simple prueba de carga.

Kubeless tiene la imagen de docker mas simple de todas, y la parte de copia y ejecución sucede en el propio container de ejecución. Esto se puede considerar una ventaja o desventaja, según el contexto en que lo vayas a usar. Y está basado únicamente en definiciones de objetos de kubernetes. Incluso se podría manejar únicamente con el CLI de kubernetes. Aunque también proveen un CLI que es demasiado verboso, no se puede desplegar con configuración únicamente. Encontrar la URL del servicio de cada función ha sido complicado.

Fission propone una serie de conceptos como Environments, Endpoints, Packages y Workflow que en la teoría son muy interesantes. Pero luego en la práctica no hemos conseguido hacer funcionar un workflow. Además están en mitad de un re-factor importante y mucha parte de la documentación se refiere a la futura versión dos, que no es la que te puedes instalar por defecto. Dejando la documentación en un estado lamentable.

Por último está Nuclio, que ha sido el último en llegar al grupo de Frameworks, pero parece que han aprendido mucho de los otros y han solucionado bastantes de sus problemas con éxito. Es el que provee un contexto muy completo al momento de ejecutar la función, dando acceso a un logger, a persistencia y alguna cosa más. Esto simplifica mucho la tarea de revisar logs de cada función. El CLI está muy bien diseñado y es fácil de usar. Y tal vez el punto que menos nos ha gustado es que intenta llevarte a su propio IDE todo el tiempo, aunque no es una desventaja necesariamente.

(SLIDE 20, CONCLUSIONS) Después de toda la experiencia que nos ha llevado casi una semana, estas son nuestras conclusiones.

(SLIDE 21, TO IMPROVE) Hay muchos sitios donde todos los frameworks pueden mejorar.

El nivel de madurez general es bajo, esta etapa de mucho desarrollo, no están preparados para nivel de productivo.

El proceso de debugging es bastante penoso ya que aún hay una dependencia fuerte del paso de construcción de un docker, haciendo que el tiempo entre prueba y error sea largo.

Por esto mismo el proceso de despliegue es lento, al menos en tiempo de desarrollo.

Los tutoriales están muy bien, pero encontrar los logs, aunque parece algo obvio, no ha sido siempre fácil. En entorno local, será peor en un entorno productivo.

En general falta pulir bastante la experiencia para los desarrolladores.


(SLIDE 22, BENEFITS)

Pero no todo son malas noticias, para terminar con una nota positiva. Creemos que al final estas soluciones se harán más comunes, e irán mejorando con el uso y el tiempo. Ya que estas soluciones si que tienen beneficios claros.

- Permiten enfocarse en el código y no la infraestructura.
- Permiten flexibilidad para seleccionar el lenguaje más adecuado para resolver cada parte de un problema.
- Los IDE dan otra herramienta muy útil y puede acercar a desarrolladores de todo tipo a crear funciones sin preocupaciones ni conocimientos de la infraestructura.
- Los CLIs son también muy útiles, tanto durante el desarrollo como herramienta de soporte para el momento de automatizar los despliegue.

Pero las dos mayores ventajas que dan es la separación de los proveedores como AWS. Todos estos frameworks no son más que capas que te permiten que la infraestructura o la cloud sean una pieza más fácilmente reemplazable, llevar por ejemplo funciones hechas para OpenFaas de AWS a Google no requiere dedicar esfuerzo en cuanto revisiones de código necesarias para migrar de una infraestructura a otra.

